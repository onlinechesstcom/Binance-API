﻿using Binance.Net.Clients;
using Binance.Net.Interfaces;
using Binance.Net.Objects;
using Binance.Net.Objects.Models.Futures.Socket;
using Binance.Net.Objects.Models.Spot.Socket;
using CryptoExchange.Net.Authentication;
using CryptoExchange.Net.CommonObjects;
using CryptoExchange.Net.Sockets;
using Microsoft.Extensions.Logging;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using TheBoys.Motherz_Milk;
using static System.Net.Mime.MediaTypeNames;

namespace TheBoys
{
    class Program
    {
        public static BinanceHandler Binancehandler { get; set; }
        public static readonly object locked = new object();
        public static void Write(string Type, DateTime Timestamp, string msg)
        {
            var message = $"{Timestamp}\t{msg}\r\n";
            Console.Write(message);
            lock (locked)
                File.AppendAllText(Type + ".txt", message);
        }
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException +=
                                    new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

            Console.WriteLine("TheBoys Project - Mozer's Milk v0.0.1");
            Console.WriteLine("Initilizing scanner...");
            Console.WriteLine("Enter the trigger:");
            var t = Console.ReadLine();
            Console.WriteLine("Enter crypto name:");
            var Crypto = Console.ReadLine();
            decimal SignalTrigger = decimal.Parse(t);
            Console.WriteLine("Enter A:");
            decimal SignalTrigger1 = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter B:");
            decimal SignalTrigger2 = decimal.Parse(Console.ReadLine());
            Binancehandler = new BinanceHandler("jPlO76zMTjWTeE1tir0pBT4EH7eOQYXQS6jsw9Uy6EqQ3LUXDfPdJ4NepaP8Br7G",
                             "fkssaTZDJbQcXCONJHrhPjwtpnClvNEp47kRkcjFl6ZEqa52KIlN7PsVvkFEUwdz",
                             Crypto,
                             false,
                             SignalTrigger);
            Binancehandler.SignalTrigger1=SignalTrigger1;
            Binancehandler.SignalTrigger2=SignalTrigger2;
        //ReSubTD:
        //var Sub = Binancehandler.Subscribe(Common.BinanceSubscriptions.Tickerdata);
        //if (Sub)
        //    Write(DateTime.UtcNow, "Subscibed to Binance Tickerdata");
        //else
        //{
        //    Write(DateTime.UtcNow, "Error see console for decription");
        //    goto ReSubTD;
        //}
        ReSubOB:
            var Sub = Binancehandler.Subscribe(Common.BinanceSubscriptions.OrderBook);
            if (Sub)
                Write("Log", DateTime.UtcNow, "Subscibed to Binance OrderBook");
            else
            {
                Write("Log", DateTime.UtcNow, "Error see console for decription");
                goto ReSubOB;
            }
        ReSubAT:
             Sub = Binancehandler.Subscribe(Common.BinanceSubscriptions.AggregatedTrades);
            if (Sub)
                Write("Log", DateTime.UtcNow, "Subscibed to Binance AggregatedTrades");
            else
            {
                Write("Log", DateTime.UtcNow, "Error see console for decription");
                goto ReSubAT;
            }

        ReSubTD:
            Sub = Binancehandler.Subscribe(Common.BinanceSubscriptions.Tickerdata);
            if (Sub)
                Write("Log", DateTime.UtcNow, "Subscibed to Binance Tickerdata");
            else
            {
                Write("Log", DateTime.UtcNow, "Error see console for decription");
                goto ReSubTD;
            }
        ReSubAL:
            Sub = Binancehandler.Subscribe(Common.BinanceSubscriptions.AllLiquidation);
            if (Sub)
                Write("Log", DateTime.UtcNow, "Subscibed to Binance AllLiquidation");
            else
            {
                Write("Log", DateTime.UtcNow, "Error see console for decription");
                goto ReSubAL;
            }
            Console.WriteLine("Scanner initilized.");
            while (true)
            {
                Thread.Sleep(1);
            }
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = (Exception)e.ExceptionObject;
            File.AppendAllText("error.txt", Newtonsoft.Json.JsonConvert.SerializeObject(e) + "\r\n" + ex.ToString() + "\r\n");
        }
    }
}
