﻿using Binance.Net.Enums;
using Binance.Net.Objects.Models.Futures.Socket;
using Binance.Net.Objects.Models.Spot.Socket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace TheBoys
{
    namespace Motherz_Milk
    {
        public static class TimerExtensions
        {
            public static void Reset(this Timer timer)
            {
                timer.Stop();
                timer.Start();
            }
        }
        public class OrderBlock
        {
            public decimal Start { get; set; }
            public decimal End { get; set; }
            public decimal Quantity { get; set; }

        }
        public class Common
        {
            public sealed class ExtendedOrder
            {
                public DateTime CreatedAt { get; set; }
                public List<decimal> Qtyy = new List<decimal>();
                public List<BinanceStreamAggregatedTrade> Trades = new List<BinanceStreamAggregatedTrade>();
                public OrderSide Side { get; set; }
            }


            public enum BinanceSubscriptions
            {
                OrderBook,
                AggregatedTrades,
                Tickerdata,
                AllLiquidation
            }
            public enum RecordType
            {
                NewOrder,
                EditOrder,
                DeleteOrder,
                Trade,
                TickerData
            }
            public sealed class Record
            {
                public DateTime Timestamp { get; set; }
                public int Side { get; set; }
                public RecordType Type { get; set; }
                public decimal Price { get; set; }
                public decimal Qty { get; set; }
            }
            public sealed class Signal
            {
                public DateTime Time { get; set; }
                public BinanceFuturesStreamLiquidation Liq { get; set; }
                public OrderSide Side { get; set; }
                public bool IsSuperSignal { get; set; }

            }

        }
    }
}