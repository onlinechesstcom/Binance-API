﻿using Binance.Net.Clients;
using Binance.Net.Interfaces;
using Binance.Net.Objects.Models.Futures.Socket;
using Binance.Net.Objects;
using CryptoExchange.Net.Authentication;
using CryptoExchange.Net.Objects;
using CryptoExchange.Net.Sockets;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using static TheBoys.Motherz_Milk.Common;
using Binance.Net.Enums;
using Binance.Net.Objects.Models.Spot.Socket;
using System.Linq;
using System.Threading.Tasks;
using CryptoExchange.Net.Logging;
using System.Timers;
using System.Security.Policy;
using System.Net.Mail;
using System.Net;
using System.Collections.Concurrent;

namespace TheBoys
{
    namespace Motherz_Milk
    {
        class BinanceHandler
        {
            public BinanceClient WebClient { get; set; }
            public BinanceSocketClient SocketClient { get; set; }
            public DataEvent<BinanceFuturesStreamBookPrice> TickerData { get; set; }
            public Dictionary<decimal, decimal> OrderBookBids = new Dictionary<decimal, decimal>();
            public Dictionary<decimal, decimal> OrderBookAsks = new Dictionary<decimal, decimal>();
            public Queue<Record> Records { get; set; }
            BinanceFuturesStreamLiquidation LastLiquid { get; set; }
            BinanceStreamAggregatedTrade LastTrade { get; set; }
            Signal LastSignal { get; set; }
            private decimal SignalTrigger { get; set; }
            public decimal SignalTrigger2 { get; set; }
            public decimal SignalTrigger1 { get; set; }
            public decimal BigBid { get; set; }
            public decimal BigAsk { get; set; }
            public List<Signal> Signals { get; set; }
            public string Symbol { get; set; }
            public bool WriteOrderBook { get; set; }
            public readonly object Key = new object(), Key2 = new object();
            public List<BinanceFuturesStreamLiquidation> LastLiquidations { get; set; }


            private List<BinanceFuturesStreamLiquidation> lastLiquidations = new List<BinanceFuturesStreamLiquidation>();
            ConcurrentDictionary<decimal, decimal> OBBids { get; set; } = new ConcurrentDictionary<decimal, decimal>();
            ConcurrentDictionary<decimal, decimal> OBAsks { get; set; } = new ConcurrentDictionary<decimal, decimal>();
            private void ConfigureSubscription(BinanceSubscriptions Subscription, CallResult<UpdateSubscription> subscription)
            {
                //subscription.Data.Exception += data => { Socket_Exception(Subscription, data); };
                subscription.Data.ConnectionClosed += new Action(() => { Socket_ConnectionClosed(Enum.GetName(typeof(BinanceSubscriptions), Subscription)); });
            }
            public bool Subscribe(BinanceSubscriptions Subscription)
            {
                if (Subscription == BinanceSubscriptions.OrderBook)
                {
                    var subscription = SocketClient.UsdFuturesStreams.SubscribeToOrderBookUpdatesAsync(Symbol, 100, data => ThreadPool.QueueUserWorkItem(BinanceHandler_OrderBookUpdate, data)).Result;
                    if (subscription.Success)
                        ConfigureSubscription(Subscription, subscription);
                    subscription = SocketClient.UsdFuturesStreams.SubscribeToPartialOrderBookUpdatesAsync(Symbol, 20, 250, data => ThreadPool.QueueUserWorkItem(BinanceHandler_OrderBookUpdate, data)).Result;
                    if (subscription.Success)
                        ConfigureSubscription(Subscription, subscription);
                    return subscription.Success;
                }
                else if (Subscription == BinanceSubscriptions.AggregatedTrades)
                {
                    var subscription = SocketClient.UsdFuturesStreams.SubscribeToAggregatedTradeUpdatesAsync(Symbol, BinanceHandler_AggregatedTrades).Result;
                    if (subscription.Success)
                    {
                        ConfigureSubscription(Subscription, subscription);
                        //SignalSW.Enabled = true;
                    }
                    return subscription.Success;
                }
                else if (Subscription == BinanceSubscriptions.AllLiquidation)
                {
                    var subscription = SocketClient.UsdFuturesStreams.SubscribeToAllLiquidationUpdatesAsync(data => {
                        ThreadPool.QueueUserWorkItem(state =>
                        {
                            DataEvent<BinanceFuturesStreamLiquidation> obj = (DataEvent<BinanceFuturesStreamLiquidation>)state;
                            BinanceHandler_AllLiquidation(obj);

                        }, data);
                    }).Result;
                    if (subscription.Success)
                        ConfigureSubscription(Subscription, subscription);
                    return subscription.Success;
                }
                else
                {
                    var subscription = SocketClient.UsdFuturesStreams.SubscribeToBookTickerUpdatesAsync(Symbol, BinanceHandler_TickerData).Result;
                    if (subscription.Success)
                        ConfigureSubscription(Subscription, subscription);
                    return subscription.Success;
                }
            }

            private void BinanceHandler_KLineUpdate(DataEvent<IBinanceStreamKlineData> obj)
            {
                switch (obj.Data.Data.Interval)
                {
                    case KlineInterval.FourHour:

                        break;
                }
            }

            int buys = 0; int sells = 0;
            private void BinanceHandler_OrderBookUpdate(object state)
            {
                DataEvent<IBinanceFuturesEventOrderBook> Update = (DataEvent<IBinanceFuturesEventOrderBook>)state;
                var t = Stopwatch.StartNew();

                foreach (var temp in Update.Data.Asks)
                {
                    if (temp.Quantity == 0)
                    {
                        OrderBookAsks.Remove(temp.Price);
                        continue;
                    }
                    if (!OrderBookAsks.TryGetValue(temp.Price, out _))
                    {
                        try
                        {
                            OrderBookAsks.Add(temp.Price, temp.Quantity);
                        }
                        catch { }
                        continue;
                    }
                    try
                    {
                        OrderBookAsks[temp.Price] = temp.Quantity;
                    }
                    catch { }
                }
                foreach (var temp in Update.Data.Bids)
                {
                    if (temp.Quantity == 0)
                    {
                        _ = OrderBookBids.Remove(temp.Price);
                        continue;
                    }
                    if (!OrderBookBids.TryGetValue(temp.Price, out _))
                    {
                        try
                        {
                            OrderBookBids.Add(temp.Price, temp.Quantity);
                        }
                        catch { }
                        continue;
                    }
                    try
                    {
                        OrderBookBids[temp.Price] = temp.Quantity;
                    }
                    catch { }
                }
                t.Stop();
                if (t.ElapsedMilliseconds > 250)
                {
                    Console.WriteLine("Proccessing time > 250ms");
                }
                Thread.Sleep(1);
            }
            private void BinanceHandler_AllLiquidation(DataEvent<BinanceFuturesStreamLiquidation> obj)
            {
                var ping = DateTime.UtcNow.Subtract(obj.Data.Timestamp);
                if (ping.TotalSeconds > 1)
                    Console.WriteLine("Ping:" + ping.TotalMilliseconds);
                if (obj.Data.Symbol.ToLower() == Symbol.ToLower())
                {
                    string log = $"{obj.Data.Timestamp}\t{obj.Data.QuantityFilled}/{obj.Data.Quantity}\tPrice:{obj.Data.Price}\tAvgPrice:{obj.Data.AveragePrice}\t{obj.Data.Side}\r\n\t\tsells:{sellQty}\tbuys:{buyQty}";
                    if (obj.Data.Side == OrderSide.Buy)
                        sells++;
                    else
                        buys++;
                    log += $"\tNumberofSells:{buys}\tNumberofBuys:{sells}\tBid:{TickerData.Data.BestAskQuantity}\tAsk:{TickerData.Data.BestBidQuantity}";
                    File.AppendAllText("Liquidations.txt", $"{log}\r\n");
                    if (LastLiquid == null)
                    {
                        LastLiquid = obj.Data;
                        return;
                    }
                    if (LastLiquid.Side == obj.Data.Side)
                    {

                        var newSignal = new Signal()
                        {
                            Time = obj.Data.Timestamp,
                            Side = obj.Data.Side,
                            Liq = LastLiquid
                        };
                        string Warning = "";
                        if (obj.Data.Side == OrderSide.Sell)
                        {
                            if (LastLiquid.AveragePrice > obj.Data.AveragePrice
                                || LastLiquid.Price > obj.Data.Price
                                || LastLiquid.AveragePrice == obj.Data.AveragePrice
                                || LastLiquid.Price == obj.Data.Price
                                || LastLiquid.AveragePrice == LastLiquid.Price
                                || obj.Data.AveragePrice == obj.Data.Price)
                                Warning = "\tHigh Risk";
                        }
                        else
                        {
                            if (LastLiquid.AveragePrice < obj.Data.AveragePrice
                                || LastLiquid.Price < obj.Data.Price
                                || LastLiquid.AveragePrice == obj.Data.AveragePrice
                                || LastLiquid.Price == obj.Data.Price
                                || LastLiquid.AveragePrice == LastLiquid.Price
                                || obj.Data.AveragePrice == obj.Data.Price)
                                Warning = "\tHigh Risk";
                        }

                        if (decimal.Round((Math.Abs(LastLiquid.Price - obj.Data.Price) / LastLiquid.Price) * SignalTrigger, 2) > (decimal)5)
                        {
                            Warning = "\tHigh Risk";
                        }
                        if (LastLiquid.Timestamp.Subtract(obj.Data.Timestamp).TotalSeconds > 60)
                        {
                            Warning = "\tHigh Risk";
                        }
                        string strSide = (obj.Data.Side == OrderSide.Sell ? "Sell" : "Buy");
                        string strSignal = $"{newSignal.Time}\t{strSide}\t{obj.Data.AveragePrice}\tBP:{(LastLiquid.Side == OrderSide.Buy ? TickerData.Data.BestBidPrice.ToString() : TickerData.Data.BestBidPrice.ToString())}{Warning}";
                        if (buys >= 1 && buys <= 22 && sells >= 0 & sells <= 14)
                        {
                            if (TickerData.Data.BestBidQuantity > SignalTrigger1 && TickerData.Data.BestAskQuantity < TickerData.Data.BestBidQuantity)
                            {
                                File.AppendAllText("newSignal.log", $"{log}\r\n");
                                ThreadPool.QueueUserWorkItem(new WaitCallback(delegate
                                {
                                    //  sendEmail("", log, "Signal " + obj.Data.Timestamp.ToString() + " " + obj.Data.Symbol);
                                }), null);
                            }
                        }
                        if (sells >= 1 && sells <= 22 && buys >= 0 & buys <= 14)
                        {
                            if (TickerData.Data.BestAskQuantity > SignalTrigger2 && TickerData.Data.BestBidQuantity < TickerData.Data.BestAskQuantity)
                            {
                                File.AppendAllText("newSignal.log", $"{log}\r\n");
                                ThreadPool.QueueUserWorkItem(new WaitCallback(delegate
                                {
                                 //  sendEmail("", log, "Signal " + obj.Data.Timestamp.ToString() + " " + obj.Data.Symbol);
                                }), null);
                            }
                        }
                        if (LastSignal != null ? LastSignal.Side != newSignal.Side : true)
                        {
                            buys = 0;
                            sells = 0;
                            LastSignal = newSignal;



                        }
                    }
                    LastLiquid = obj.Data;
                }
            }
            public List<OrderBlock> GetOrderBlock(Dictionary<decimal, decimal> dic)
            {
                List<OrderBlock> ob = new List<OrderBlock>();
                var newDic = dic.OrderBy(x => x.Key);
                int counter = 0;
                int groupSize = 100;
                IEnumerable<Dictionary<decimal, decimal>> result = newDic
                    .GroupBy(x => counter++ / groupSize)
                    .Select(g => g.ToDictionary(h => h.Key, h => h.Value));

                foreach (Dictionary<decimal, decimal> rsl in result)
                {
                    ob.Add(new OrderBlock() { Start = rsl.Min(x => x.Key), End = rsl.Max(x => x.Key), Quantity = rsl.Sum(x => x.Value) });
                }
                return ob;
            }
            public void sendEmail(string addresses, string body, string subject)
            {
                var fromAddress = new MailAddress("dgsgs@gmail.com", "grdgdr");
                const string fromPassword = "gesgsegesg!";
                using (var smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
                })
                using (var message = new MailMessage()
                {
                    Subject = subject,
                    Body = body,
                    From = fromAddress,
                })
                {
                    foreach (var address in addresses.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        message.To.Add(address);
                    }
                    smtp.Send(message);
                }

            }
            private decimal buyQty = 0;
            private decimal sellQty = 0;
            private void BinanceHandler_AggregatedTrades(DataEvent<BinanceStreamAggregatedTrade> obj)
            {
                if (obj.Data.BuyerIsMaker)
                    buyQty += obj.Data.Quantity;
                else
                    sellQty += obj.Data.Quantity;
                LastTrade = obj.Data;
            }
            private void SignalSW_CallBack(object sender, ElapsedEventArgs e)
            {
                //File.AppendAllText("Trades.txt", $"{DateTime.UtcNow.Subtract(TimeSpan.FromSeconds(10))}\tB:{buyQty.ToString()}\tS:{sellQty}\r\n");
                //buyQty = 0; sellQty = 0;
            }
            private void Socket_Exception(BinanceSubscriptions Subscription, Exception obj)
            {
                string msg = string.Format("Exception in socket client:\r\nSubscription{0}\r\nMessage:{1}\r\n\t{2}\r\nRetrying...", Enum.GetName(typeof(BinanceSubscriptions), Subscription), obj.Message, obj.StackTrace);
                File.AppendAllText("SocketExceptions.txt", msg + "\r\n" + obj.Source + "\r\n");
                Console.WriteLine(msg);
                Console.WriteLine("Results:" + Subscribe(Subscription).ToString());
            }
            private void Socket_ConnectionClosed(string Subscription)
            {
                Console.WriteLine("Close connection in socket client:\r\nSubscription{0}\r\nMessage:{1}", Subscription);
            }

            private void BinanceHandler_TickerData(DataEvent<BinanceFuturesStreamBookPrice> obj)
            {
                if (obj.Data.BestAskQuantity >= 300 || obj.Data.BestBidQuantity >= 300)
                {
                    string log = obj.Data.EventTime.ToString("HH:mm:ss:fff");
                    if (obj.Data.BestAskQuantity >= 300)
                    {
                        log += $"\tASK\t{obj.Data.BestAskQuantity}@{obj.Data.BestAskPrice}\t";
                    }
                    if (obj.Data.BestBidQuantity >= 300)
                    {
                        log += $"\tBID\t{obj.Data.BestBidQuantity}@{obj.Data.BestBidPrice}\t";

                    }
                    //lock (Key2)
                    //    File.AppendAllText("TickerData.log", log + "\r\n");
                }
                TickerData = obj;
            }
            public BinanceHandler(string ApiKey, string ApiSecret, string Symbol, bool WriteOrderBook, decimal Trigger)
            {
                Signals = new List<Signal>();
                SignalTrigger = Trigger;
                this.Symbol = Symbol;
                BinanceClient.SetDefaultOptions(new BinanceClientOptions()
                {
                    UsdFuturesApiOptions = new BinanceApiClientOptions()
                    {
                        OutputOriginalData = true
                    },
                    ApiCredentials = new BinanceApiCredentials(ApiKey, ApiSecret),
                    LogLevel = LogLevel.Debug
                });
                BinanceSocketClient.SetDefaultOptions(new BinanceSocketClientOptions()
                {
                    UsdFuturesStreamsOptions = new BinanceSocketApiClientOptions()
                    {
                        AutoReconnect = true,
                        OutputOriginalData = true
                    },
                    ApiCredentials = new BinanceApiCredentials(ApiKey, ApiSecret),
                    LogLevel = LogLevel.Debug,
                });
                WebClient = new BinanceClient();
                SocketClient = new BinanceSocketClient();
                this.WriteOrderBook = WriteOrderBook;
                Records = new Queue<Record>();
                //SignalSW.Elapsed += SignalSW_CallBack;
                //SignalSW.Interval = 5000;
            }
        }
    }
}
